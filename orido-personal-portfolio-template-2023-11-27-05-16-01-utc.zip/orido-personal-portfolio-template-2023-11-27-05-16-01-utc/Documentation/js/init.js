
jQuery(document).ready(function(){

	"use strict";
	
	jQuery('.anchor_nav').onePageNav();
	
});



